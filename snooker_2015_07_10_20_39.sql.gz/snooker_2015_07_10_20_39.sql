-- Status:25:1071:MP_0:snooker:php:1.24.4::5.6.19:1:::utf8:EXTINFO
--
-- TABLE-INFO
-- TABLE|frame|99|16384||InnoDB
-- TABLE|frame_detail|457|16765|2015-06-23 23:42:04|MyISAM
-- TABLE|frame_result|194|16384||InnoDB
-- TABLE|map_city|5|2352|2015-07-09 00:04:27|MyISAM
-- TABLE|match|21|16384||InnoDB
-- TABLE|match_player|42|16384||InnoDB
-- TABLE|national|16|2392|2015-06-10 23:56:01|MyISAM
-- TABLE|player|66|5152|2015-06-21 23:21:27|MyISAM
-- TABLE|position|9|2268|2015-06-23 23:16:34|MyISAM
-- TABLE|round|8|2220|2015-06-05 21:37:52|MyISAM
-- TABLE|season|1|2080|2015-06-10 00:06:17|MyISAM
-- TABLE|season_player|1|16384||InnoDB
-- TABLE|season_tournament|2|16384||InnoDB
-- TABLE|status_frame_detail|2|2088|2015-06-08 22:53:53|MyISAM
-- TABLE|status_match|4|16384||InnoDB
-- TABLE|status_national|0|1024|2015-06-05 21:37:52|MyISAM
-- TABLE|status_player|1|2068|2015-06-06 00:02:08|MyISAM
-- TABLE|status_season|1|2068|2015-06-06 09:52:44|MyISAM
-- TABLE|status_season_tournament|4|2128|2015-06-06 09:58:35|MyISAM
-- TABLE|status_tournament|1|2068|2015-06-06 09:59:16|MyISAM
-- TABLE|tournament|5|2200|2015-06-06 11:05:16|MyISAM
-- TABLE|tournament_player|75|16384||InnoDB
-- TABLE|tournament_prize|5|16384||InnoDB
-- TABLE|tournament_round|7|16384||InnoDB
-- TABLE|weather_city|45|4368|2015-07-11 00:45:01|MyISAM
-- EOF TABLE-INFO
--
-- Dump by MySQLDumper 1.24.4 (http://mysqldumper.net)
/*!40101 SET NAMES 'utf8' */;
SET FOREIGN_KEY_CHECKS=0;
-- Dump created: 2015-07-10 20:39

--
-- Create Table `frame`
--

DROP TABLE IF EXISTS `frame`;
CREATE TABLE `frame` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `match_id` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=117 DEFAULT CHARSET=utf8;

--
-- Data for Table `frame`
--

/*!40000 ALTER TABLE `frame` DISABLE KEYS */;
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('1','1','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('2','1','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('3','1','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('4','1','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('5','4','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('8','4','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('9','4','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('10','1','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('11','2','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('12','2','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('13','2','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('14','2','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('15','2','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('16','2','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('17','7','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('18','7','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('19','4','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('20','4','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('21','4','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('22','4','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('23','5','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('24','5','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('25','5','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('26','5','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('27','5','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('43','6','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('44','6','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('45','6','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('46','6','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('47','6','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('48','6','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('49','6','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('50','7','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('51','8','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('52','8','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('53','8','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('54','8','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('55','8','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('56','8','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('57','7','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('58','7','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('59','7','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('60','7','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('61','9','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('62','9','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('63','9','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('64','9','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('65','9','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('66','9','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('67','12','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('68','12','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('69','12','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('70','12','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('71','12','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('72','16','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('73','16','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('74','16','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('75','16','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('76','16','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('77','16','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('78','17','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('79','17','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('80','17','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('81','17','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('82','17','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('83','18','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('84','18','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('85','18','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('86','18','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('87','18','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('88','18','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('89','19','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('90','19','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('91','19','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('92','19','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('93','19','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('94','19','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('95','20','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('96','20','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('97','20','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('98','20','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('99','21','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('100','21','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('101','21','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('102','22','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('103','22','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('104','22','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('105','22','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('106','22','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('107','21','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('108','21','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('109','21','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('110','23','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('111','23','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('112','23','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('113','23','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('114','23','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('115','23','1');
INSERT INTO `frame` (`id`,`match_id`,`status`) VALUES ('116','23','1');
/*!40000 ALTER TABLE `frame` ENABLE KEYS */;


--
-- Create Table `frame_detail`
--

DROP TABLE IF EXISTS `frame_detail`;
CREATE TABLE `frame_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `frame_id` int(11) NOT NULL,
  `player_id` int(11) NOT NULL,
  `result_score` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=478 DEFAULT CHARSET=latin1;

--
-- Data for Table `frame_detail`
--

/*!40000 ALTER TABLE `frame_detail` DISABLE KEYS */;
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('1','1','9','4','2');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('2','1','9','7','2');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('3','1','1','36','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('4','1','9','15','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('5','1','1','72','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('6','2','1','14','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('7','2','9','37','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('8','2','9','4','2');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('9','2','9','35','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('10','3','9','8','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('11','3','1','126','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('12','4','1','27','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('13','4','9','18','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('14','4','9','6','2');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('15','4','9','36','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('16','4','1','59','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('17','5','7','28','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('18','5','7','21','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('19','5','11','26','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('20','5','11','4','2');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('21','5','11','12','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('22','5','11','14','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('23','5','11','7','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('31','8','7','52','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('32','8','11','8','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('33','8','7','38','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('34','9','7','27','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('35','9','11','4','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('36','9','11','17','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('37','9','11','25','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('38','9','7','10','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('39','9','7','12','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('40','9','7','25','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('41','10','1','36','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('42','10','9','12','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('43','10','1','39','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('44','10','9','4','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('45','11','4','12','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('46','11','4','8','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('47','11','10','25','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('48','11','4','13','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('49','11','10','7','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('50','11','4','11','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('51','11','10','61','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('52','12','10','4','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('53','12','10','7','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('54','12','4','116','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('55','13','4','23','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('56','13','10','57','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('57','13','4','6','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('58','13','10','12','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('59','13','10','9','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('60','14','10','4','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('61','14','4','88','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('62','15','4','24','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('63','15','10','19','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('64','15','4','27','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('65','15','4','45','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('66','16','4','4','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('67','16','4','4','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('68','16','4','7','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('69','16','4','4','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('70','16','4','4','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('71','16','4','4','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('72','16','10','26','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('73','16','10','18','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('74','16','4','72','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('75','16','10','1','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('76','17','5','6','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('77','17','5','34','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('78','17','13','17','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('79','17','13','27','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('80','17','13','41','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('81','18','13','97','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('82','19','11','44','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('83','19','11','38','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('84','20','7','7','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('85','20','7','25','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('86','20','11','1','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('87','20','11','6','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('88','20','7','16','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('89','20','7','19','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('90','20','11','10','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('91','20','7','27','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('92','21','11','13','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('93','21','7','35','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('94','21','11','11','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('95','21','11','48','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('96','22','7','1','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('97','22','11','108','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('98','23','12','24','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('99','23','12','8','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('100','23','6','13','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('101','23','6','66','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('102','24','6','22','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('103','24','6','7','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('104','24','12','57','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('105','24','6','16','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('106','24','6','11','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('107','24','6','17','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('108','25','6','1','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('109','25','12','12','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('110','25','6','6','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('111','25','12','17','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('112','25','12','7','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('113','25','6','4','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('114','25','12','35','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('115','25','12','14','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('116','26','12','8','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('117','26','12','1','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('118','26','6','115','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('119','27','6','24','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('120','27','12','6','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('121','27','6','17','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('122','27','6','10','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('123','27','6','51','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('141','44','8','1','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('140','44','8','6','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('139','44','15','21','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('138','43','15','12','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('137','43','15','77','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('142','44','15','17','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('143','44','15','28','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('144','44','15','13','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('145','45','8','88','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('146','46','15','25','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('147','46','15','19','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('148','46','8','56','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('149','46','15','4','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('150','46','8','20','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('151','47','15','37','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('152','47','15','69','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('153','48','15','4','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('154','48','15','4','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('155','48','15','6','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('156','48','8','29','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('157','48','8','1','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('158','48','15','15','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('159','48','15','7','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('160','48','8','16','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('161','48','8','33','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('162','48','15','8','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('163','48','8','18','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('164','49','8','131','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('165','50','5','36','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('166','50','5','1','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('167','50','13','20','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('168','50','5','8','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('169','50','13','3','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('170','50','5','18','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('171','50','5','17','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('172','51','20','5','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('173','51','16','11','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('174','51','16','1','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('175','51','20','102','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('176','52','20','24','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('177','52','20','4','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('178','52','16','8','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('179','52','20','1','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('180','52','16','33','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('181','52','16','1','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('182','52','20','15','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('183','52','16','7','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('184','52','16','46','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('185','53','20','105','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('186','54','20','24','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('187','54','20','7','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('188','54','16','6','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('189','54','16','39','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('190','54','20','41','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('191','54','16','1','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('192','55','20','7','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('193','55','20','4','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('194','55','16','61','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('195','55','16','24','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('196','56','16','9','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('197','56','20','15','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('198','56','20','7','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('199','56','20','72','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('200','57','5','24','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('201','57','5','1','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('202','57','13','7','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('203','57','13','29','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('204','57','5','10','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('205','57','5','38','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('206','58','5','6','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('207','58','13','14','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('208','58','5','82','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('209','59','5','4','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('210','59','5','4','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('211','59','5','4','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('212','59','5','15','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('213','59','13','7','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('214','59','5','6','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('215','59','13','1','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('216','59','13','21','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('217','59','5','1','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('218','59','5','4','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('219','59','13','5','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('220','59','13','23','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('221','59','5','10','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('222','59','13','7','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('223','59','13','21','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('224','60','13','11','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('225','60','5','7','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('226','60','5','34','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('227','60','5','31','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('228','61','14','1','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('229','61','19','122','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('230','62','14','4','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('231','62','19','16','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('232','62','14','63','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('233','62','14','6','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('234','62','14','23','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('235','63','19','24','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('236','63','14','47','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('237','63','14','5','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('238','63','19','12','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('239','63','19','1','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('240','63','14','16','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('241','63','14','27','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('242','64','19','1','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('243','64','19','77','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('244','65','19','25','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('245','65','19','7','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('246','65','14','56','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('247','65','19','13','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('248','65','14','20','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('249','66','14','4','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('250','66','14','5','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('251','66','14','66','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('252','67','3','83','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('253','68','18','46','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('254','68','3','5','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('255','68','3','18','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('256','68','18','27','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('257','69','18','13','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('258','69','3','54','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('259','69','3','12','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('260','69','3','66','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('261','70','3','1','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('262','70','3','117','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('263','71','3','63','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('264','71','18','12','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('265','71','18','7','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('266','71','3','54','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('267','72','2','56','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('268','72','65','27','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('269','72','65','10','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('270','72','2','7','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('271','72','2','37','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('272','73','2','19','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('273','73','65','20','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('274','73','65','24','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('275','73','65','24','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('276','74','2','108','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('277','75','2','25','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('278','75','2','6','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('279','75','65','77','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('280','76','2','16','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('281','76','2','1','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('282','76','65','47','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('283','76','2','73','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('284','77','65','11','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('285','77','2','17','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('286','77','2','35','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('287','77','65','29','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('288','77','2','4','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('289','77','2','25','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('290','78','68','17','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('291','78','68','20','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('292','78','30','6','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('293','78','30','19','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('294','78','68','18','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('295','78','30','11','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('296','78','68','16','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('297','79','30','32','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('298','79','30','12','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('299','79','30','8','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('300','79','68','26','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('301','79','68','50','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('302','80','30','23','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('303','80','68','37','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('304','80','30','20','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('305','80','30','49','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('306','81','68','61','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('307','81','68','44','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('308','82','68','45','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('309','82','68','1','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('310','82','30','17','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('311','82','68','15','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('312','82','30','8','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('313','82','30','20','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('314','82','68','3','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('315','82','68','9','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('316','83','31','55','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('317','83','31','1','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('318','83','14','17','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('319','83','14','30','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('320','83','31','27','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('321','84','14','4','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('322','84','31','13','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('323','84','14','12','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('324','84','14','63','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('325','85','31','6','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('326','85','14','1','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('327','85','31','4','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('328','85','31','17','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('329','85','14','5','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('330','85','31','1','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('331','85','31','4','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('332','85','31','6','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('333','85','14','29','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('334','85','14','59','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('335','86','14','17','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('336','86','31','112','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('337','87','31','15','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('338','87','14','8','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('339','87','31','78','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('340','88','14','13','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('341','88','31','6','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('342','88','31','27','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('343','88','14','18','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('344','88','31','13','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('345','88','31','26','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('346','89','32','16','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('347','89','32','27','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('348','89','56','13','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('349','89','32','4','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('350','89','56','54','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('351','90','32','55','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('352','90','32','6','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('353','90','56','15','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('354','90','32','38','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('355','91','56','24','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('356','91','32','8','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('357','91','56','9','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('358','91','32','56','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('359','91','32','7','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('360','92','32','17','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('361','92','56','7','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('362','92','32','7','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('363','92','56','31','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('364','92','56','1','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('365','92','56','35','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('366','93','32','86','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('367','94','56','9','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('368','94','56','16','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('369','94','32','13','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('370','94','56','4','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('371','94','32','18','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('372','94','32','22','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('373','94','32','7','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('374','95','25','12','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('375','95','67','6','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('376','95','67','76','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('377','96','25','39','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('378','96','67','27','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('379','96','25','1','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('380','96','67','17','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('381','96','67','19','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('382','97','25','6','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('383','97','25','20','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('384','97','67','53','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('385','97','25','1','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('386','97','25','7','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('387','97','67','22','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('388','98','25','19','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('389','98','67','7','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('390','98','67','34','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('391','98','67','11','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('392','98','25','5','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('393','98','67','25','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('394','99','58','6','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('395','99','58','19','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('396','99','62','27','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('397','99','58','1','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('398','99','62','4','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('399','99','62','16','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('400','99','62','33','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('401','100','58','39','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('402','100','58','16','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('403','100','58','7','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('404','100','62','1','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('405','100','58','35','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('406','101','58','66','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('407','101','62','15','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('408','101','58','17','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('409','102','24','47','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('410','102','55','33','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('411','102','55','10','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('412','102','24','3','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('413','102','55','28','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('414','103','24','122','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('415','104','24','26','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('416','104','24','1','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('417','104','55','7','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('418','104','24','57','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('419','105','24','6','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('420','105','24','131','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('421','106','55','19','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('422','106','55','17','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('423','106','24','15','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('424','106','55','6','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('425','106','24','25','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('426','106','24','53','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('427','107','58','1','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('428','107','62','10','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('429','107','58','18','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('430','107','58','6','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('431','107','58','11','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('432','107','62','44','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('433','107','62','18','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('434','108','62','34','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('435','108','62','45','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('436','109','62','17','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('437','109','58','5','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('438','109','62','32','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('439','109','62','16','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('440','109','58','7','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('441','109','62','23','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('442','110','50','9','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('443','110','27','11','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('444','110','27','4','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('445','110','50','46','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('446','110','27','13','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('447','110','50','6','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('448','110','50','23','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('449','111','50','16','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('450','111','50','4','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('451','111','27','75','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('452','112','27','4','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('453','112','50','19','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('454','112','50','1','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('455','112','27','3','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('456','112','27','27','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('457','112','50','6','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('458','112','50','15','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('459','112','27','11','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('460','112','50','1','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('461','112','27','20','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('462','113','50','7','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('463','113','50','7','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('464','113','27','29','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('465','113','50','47','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('466','113','50','14','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('467','114','27','3','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('468','114','27','119','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('469','115','50','12','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('470','115','27','5','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('471','115','27','17','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('472','115','50','66','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('473','116','27','44','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('474','116','27','1','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('475','116','50','32','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('476','116','27','6','1');
INSERT INTO `frame_detail` (`id`,`frame_id`,`player_id`,`result_score`,`status`) VALUES ('477','116','50','42','1');
/*!40000 ALTER TABLE `frame_detail` ENABLE KEYS */;


--
-- Create Table `frame_result`
--

DROP TABLE IF EXISTS `frame_result`;
CREATE TABLE `frame_result` (
  `frame_id` int(11) NOT NULL,
  `player_id` int(11) NOT NULL,
  `result_score` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`frame_id`,`player_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Data for Table `frame_result`
--

/*!40000 ALTER TABLE `frame_result` DISABLE KEYS */;
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('1','1','108','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('1','9','26','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('2','1','14','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('2','9','76','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('5','7','49','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('5','11','63','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('8','7','90','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('8','11','8','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('9','7','74','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('9','11','46','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('10','1','75','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('10','9','16','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('11','4','44','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('11','10','93','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('12','4','116','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('12','10','11','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('13','4','29','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('13','10','78','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('14','4','88','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('14','10','4','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('15','4','96','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('15','10','19','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('16','4','99','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('16','10','45','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('17','5','40','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('17','13','85','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('18','5','0','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('18','13','97','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('19','7','0','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('19','11','82','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('20','7','94','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('20','11','17','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('21','7','35','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('21','11','72','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('22','7','1','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('22','11','108','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('23','6','79','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('23','12','32','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('24','6','73','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('24','12','57','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('25','6','11','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('25','12','85','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('26','6','115','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('26','12','9','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('27','6','102','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('27','12','6','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('43','8','0','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('43','15','89','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('44','8','7','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('44','15','79','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('45','8','88','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('45','15','0','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('46','8','76','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('46','15','48','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('47','8','0','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('47','15','106','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('48','8','97','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('48','15','44','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('49','8','131','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('49','15','0','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('50','5','80','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('50','13','23','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('51','16','12','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('51','20','107','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('52','16','95','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('52','20','44','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('53','16','0','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('53','20','105','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('54','16','46','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('54','20','72','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('55','16','85','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('55','20','11','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('56','16','9','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('56','20','94','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('57','5','73','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('57','13','36','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('58','5','88','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('58','13','14','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('59','5','48','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('59','13','85','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('60','5','72','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('60','13','11','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('61','14','1','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('61','19','122','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('62','14','96','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('62','19','16','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('63','14','95','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('63','19','37','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('64','14','0','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('64','19','78','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('65','14','76','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('65','19','45','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('66','14','75','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('66','19','0','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('67','3','83','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('67','18','0','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('68','3','23','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('68','18','73','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('69','3','132','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('69','18','13','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('70','3','118','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('70','18','0','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('71','3','117','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('71','18','19','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('72','2','100','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('72','65','37','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('73','2','19','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('73','65','68','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('74','2','108','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('74','65','0','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('75','2','31','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('75','65','77','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('76','2','90','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('76','65','47','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('77','2','81','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('77','65','40','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('78','30','36','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('78','68','71','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('79','30','52','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('79','68','76','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('80','30','92','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('80','68','37','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('81','30','0','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('81','68','105','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('82','30','45','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('82','68','73','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('83','14','47','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('83','31','83','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('84','14','79','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('84','31','13','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('85','14','94','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('85','31','38','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('86','14','17','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('86','31','112','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('87','14','8','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('87','31','93','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('88','14','31','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('88','31','72','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('89','32','47','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('89','56','67','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('90','32','99','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('90','56','15','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('91','32','71','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('91','56','33','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('92','32','24','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('92','56','74','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('93','32','86','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('93','56','0','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('94','32','60','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('94','56','29','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('95','25','12','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('95','67','82','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('96','25','40','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('96','67','63','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('97','25','34','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('97','67','75','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('98','25','24','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('98','67','77','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('99','58','26','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('99','62','80','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('100','58','97','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('100','62','1','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('101','58','83','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('101','62','15','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('102','24','50','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('102','55','71','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('103','24','122','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('103','55','0','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('104','24','84','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('104','55','7','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('105','24','137','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('105','55','0','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('106','24','93','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('106','55','42','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('107','58','36','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('107','62','72','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('108','58','0','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('108','62','79','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('109','58','12','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('109','62','88','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('110','27','28','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('110','50','84','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('111','27','75','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('111','50','20','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('112','27','65','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('112','50','42','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('113','27','29','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('113','50','75','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('114','27','122','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('114','50','0','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('115','27','22','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('115','50','78','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('116','27','51','1');
INSERT INTO `frame_result` (`frame_id`,`player_id`,`result_score`,`status`) VALUES ('116','50','74','1');
/*!40000 ALTER TABLE `frame_result` ENABLE KEYS */;


--
-- Create Table `map_city`
--

DROP TABLE IF EXISTS `map_city`;
CREATE TABLE `map_city` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(300) NOT NULL,
  `latitude` varchar(50) NOT NULL,
  `longtitude` varchar(50) NOT NULL,
  `zoom` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Data for Table `map_city`
--

/*!40000 ALTER TABLE `map_city` DISABLE KEYS */;
INSERT INTO `map_city` (`id`,`name`,`latitude`,`longtitude`,`zoom`) VALUES ('8','Hà Nội','21.022498895327168','105.81926188468933','13');
INSERT INTO `map_city` (`id`,`name`,`latitude`,`longtitude`,`zoom`) VALUES ('2','Hải Phòng','20.854916995093387','106.67682445645332','14');
INSERT INTO `map_city` (`id`,`name`,`latitude`,`longtitude`,`zoom`) VALUES ('3','TP Hồ Chí Minh','10.785247447863549','106.65202341079711','12');
INSERT INTO `map_city` (`id`,`name`,`latitude`,`longtitude`,`zoom`) VALUES ('4','Đà Nẵng','16.05257422504084','108.21548840999603','13');
INSERT INTO `map_city` (`id`,`name`,`latitude`,`longtitude`,`zoom`) VALUES ('5','Melbourne','-37.8194323382276','144.96182149648666','13');
/*!40000 ALTER TABLE `map_city` ENABLE KEYS */;


--
-- Create Table `match`
--

DROP TABLE IF EXISTS `match`;
CREATE TABLE `match` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `season_id` int(11) NOT NULL,
  `tournament_id` int(11) NOT NULL,
  `round_id` int(11) NOT NULL,
  `created_date` varchar(15) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;

--
-- Data for Table `match`
--

/*!40000 ALTER TABLE `match` DISABLE KEYS */;
INSERT INTO `match` (`id`,`season_id`,`tournament_id`,`round_id`,`created_date`,`status`) VALUES ('1','1','1','7','1','1');
INSERT INTO `match` (`id`,`season_id`,`tournament_id`,`round_id`,`created_date`,`status`) VALUES ('2','1','1','7','1','1');
INSERT INTO `match` (`id`,`season_id`,`tournament_id`,`round_id`,`created_date`,`status`) VALUES ('4','1','1','7','1433955393','1');
INSERT INTO `match` (`id`,`season_id`,`tournament_id`,`round_id`,`created_date`,`status`) VALUES ('5','1','1','7','1433955401','1');
INSERT INTO `match` (`id`,`season_id`,`tournament_id`,`round_id`,`created_date`,`status`) VALUES ('6','1','1','7','1433955409','1');
INSERT INTO `match` (`id`,`season_id`,`tournament_id`,`round_id`,`created_date`,`status`) VALUES ('7','1','1','7','1434170603','1');
INSERT INTO `match` (`id`,`season_id`,`tournament_id`,`round_id`,`created_date`,`status`) VALUES ('8','1','1','7','1434642278','1');
INSERT INTO `match` (`id`,`season_id`,`tournament_id`,`round_id`,`created_date`,`status`) VALUES ('9','1','1','7','1434642323','1');
INSERT INTO `match` (`id`,`season_id`,`tournament_id`,`round_id`,`created_date`,`status`) VALUES ('12','1','1','7','1434734046','1');
INSERT INTO `match` (`id`,`season_id`,`tournament_id`,`round_id`,`created_date`,`status`) VALUES ('13','1','3','7','1434860918','2');
INSERT INTO `match` (`id`,`season_id`,`tournament_id`,`round_id`,`created_date`,`status`) VALUES ('14','1','3','7','1434860928','2');
INSERT INTO `match` (`id`,`season_id`,`tournament_id`,`round_id`,`created_date`,`status`) VALUES ('15','1','3','7','1434860972','1');
INSERT INTO `match` (`id`,`season_id`,`tournament_id`,`round_id`,`created_date`,`status`) VALUES ('16','1','1','7','1434877281','1');
INSERT INTO `match` (`id`,`season_id`,`tournament_id`,`round_id`,`created_date`,`status`) VALUES ('17','1','1','7','1434877312','1');
INSERT INTO `match` (`id`,`season_id`,`tournament_id`,`round_id`,`created_date`,`status`) VALUES ('18','1','1','7','1434878231','1');
INSERT INTO `match` (`id`,`season_id`,`tournament_id`,`round_id`,`created_date`,`status`) VALUES ('19','1','1','7','1434878297','1');
INSERT INTO `match` (`id`,`season_id`,`tournament_id`,`round_id`,`created_date`,`status`) VALUES ('20','1','1','7','1434863695','1');
INSERT INTO `match` (`id`,`season_id`,`tournament_id`,`round_id`,`created_date`,`status`) VALUES ('21','1','1','7','1434864209','1');
INSERT INTO `match` (`id`,`season_id`,`tournament_id`,`round_id`,`created_date`,`status`) VALUES ('22','1','1','7','1434988285','1');
INSERT INTO `match` (`id`,`season_id`,`tournament_id`,`round_id`,`created_date`,`status`) VALUES ('23','1','1','7','1435077144','1');
INSERT INTO `match` (`id`,`season_id`,`tournament_id`,`round_id`,`created_date`,`status`) VALUES ('25','1','1','7','1435077226','2');
/*!40000 ALTER TABLE `match` ENABLE KEYS */;


--
-- Create Table `match_player`
--

DROP TABLE IF EXISTS `match_player`;
CREATE TABLE `match_player` (
  `match_id` int(11) NOT NULL,
  `player_id` int(11) NOT NULL,
  `score` int(11) DEFAULT NULL,
  PRIMARY KEY (`match_id`,`player_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Data for Table `match_player`
--

/*!40000 ALTER TABLE `match_player` DISABLE KEYS */;
INSERT INTO `match_player` (`match_id`,`player_id`,`score`) VALUES ('1','1','4');
INSERT INTO `match_player` (`match_id`,`player_id`,`score`) VALUES ('1','9','1');
INSERT INTO `match_player` (`match_id`,`player_id`,`score`) VALUES ('2','4','4');
INSERT INTO `match_player` (`match_id`,`player_id`,`score`) VALUES ('2','10','2');
INSERT INTO `match_player` (`match_id`,`player_id`,`score`) VALUES ('4','7','3');
INSERT INTO `match_player` (`match_id`,`player_id`,`score`) VALUES ('4','11','4');
INSERT INTO `match_player` (`match_id`,`player_id`,`score`) VALUES ('5','6','4');
INSERT INTO `match_player` (`match_id`,`player_id`,`score`) VALUES ('5','12','1');
INSERT INTO `match_player` (`match_id`,`player_id`,`score`) VALUES ('6','8','4');
INSERT INTO `match_player` (`match_id`,`player_id`,`score`) VALUES ('6','15','3');
INSERT INTO `match_player` (`match_id`,`player_id`,`score`) VALUES ('7','5','4');
INSERT INTO `match_player` (`match_id`,`player_id`,`score`) VALUES ('7','13','3');
INSERT INTO `match_player` (`match_id`,`player_id`,`score`) VALUES ('8','16','2');
INSERT INTO `match_player` (`match_id`,`player_id`,`score`) VALUES ('8','20','4');
INSERT INTO `match_player` (`match_id`,`player_id`,`score`) VALUES ('9','14','4');
INSERT INTO `match_player` (`match_id`,`player_id`,`score`) VALUES ('9','19','2');
INSERT INTO `match_player` (`match_id`,`player_id`,`score`) VALUES ('12','3','4');
INSERT INTO `match_player` (`match_id`,`player_id`,`score`) VALUES ('12','18','1');
INSERT INTO `match_player` (`match_id`,`player_id`,`score`) VALUES ('13','62',NULL);
INSERT INTO `match_player` (`match_id`,`player_id`,`score`) VALUES ('13','64',NULL);
INSERT INTO `match_player` (`match_id`,`player_id`,`score`) VALUES ('14','7',NULL);
INSERT INTO `match_player` (`match_id`,`player_id`,`score`) VALUES ('14','13',NULL);
INSERT INTO `match_player` (`match_id`,`player_id`,`score`) VALUES ('15','60',NULL);
INSERT INTO `match_player` (`match_id`,`player_id`,`score`) VALUES ('15','63',NULL);
INSERT INTO `match_player` (`match_id`,`player_id`,`score`) VALUES ('16','2','4');
INSERT INTO `match_player` (`match_id`,`player_id`,`score`) VALUES ('16','65','2');
INSERT INTO `match_player` (`match_id`,`player_id`,`score`) VALUES ('17','30','1');
INSERT INTO `match_player` (`match_id`,`player_id`,`score`) VALUES ('17','68','4');
INSERT INTO `match_player` (`match_id`,`player_id`,`score`) VALUES ('18','14','2');
INSERT INTO `match_player` (`match_id`,`player_id`,`score`) VALUES ('18','31','4');
INSERT INTO `match_player` (`match_id`,`player_id`,`score`) VALUES ('19','32','4');
INSERT INTO `match_player` (`match_id`,`player_id`,`score`) VALUES ('19','56','2');
INSERT INTO `match_player` (`match_id`,`player_id`,`score`) VALUES ('20','25','0');
INSERT INTO `match_player` (`match_id`,`player_id`,`score`) VALUES ('20','67','4');
INSERT INTO `match_player` (`match_id`,`player_id`,`score`) VALUES ('21','58','2');
INSERT INTO `match_player` (`match_id`,`player_id`,`score`) VALUES ('21','62','4');
INSERT INTO `match_player` (`match_id`,`player_id`,`score`) VALUES ('22','24','4');
INSERT INTO `match_player` (`match_id`,`player_id`,`score`) VALUES ('22','55','1');
INSERT INTO `match_player` (`match_id`,`player_id`,`score`) VALUES ('23','27','3');
INSERT INTO `match_player` (`match_id`,`player_id`,`score`) VALUES ('23','50','4');
INSERT INTO `match_player` (`match_id`,`player_id`,`score`) VALUES ('25','23',NULL);
INSERT INTO `match_player` (`match_id`,`player_id`,`score`) VALUES ('25','63',NULL);
/*!40000 ALTER TABLE `match_player` ENABLE KEYS */;


--
-- Create Table `national`
--

DROP TABLE IF EXISTS `national`;
CREATE TABLE `national` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

--
-- Data for Table `national`
--

/*!40000 ALTER TABLE `national` DISABLE KEYS */;
INSERT INTO `national` (`id`,`name`,`status`) VALUES ('1','England','1');
INSERT INTO `national` (`id`,`name`,`status`) VALUES ('2','China','1');
INSERT INTO `national` (`id`,`name`,`status`) VALUES ('3','Scotland','1');
INSERT INTO `national` (`id`,`name`,`status`) VALUES ('4','Northern Ireland','1');
INSERT INTO `national` (`id`,`name`,`status`) VALUES ('5','India','1');
INSERT INTO `national` (`id`,`name`,`status`) VALUES ('6','Wales','1');
INSERT INTO `national` (`id`,`name`,`status`) VALUES ('7','Thailand','1');
INSERT INTO `national` (`id`,`name`,`status`) VALUES ('8','Australia','1');
INSERT INTO `national` (`id`,`name`,`status`) VALUES ('9','Republic of Ireland','1');
INSERT INTO `national` (`id`,`name`,`status`) VALUES ('10','Hong Kong','1');
INSERT INTO `national` (`id`,`name`,`status`) VALUES ('11','Belgium','1');
INSERT INTO `national` (`id`,`name`,`status`) VALUES ('12','Finland','1');
INSERT INTO `national` (`id`,`name`,`status`) VALUES ('13','Brazil','1');
INSERT INTO `national` (`id`,`name`,`status`) VALUES ('14','Norway','1');
INSERT INTO `national` (`id`,`name`,`status`) VALUES ('15','Malta','1');
INSERT INTO `national` (`id`,`name`,`status`) VALUES ('16','Isle of Man','1');
/*!40000 ALTER TABLE `national` ENABLE KEYS */;


--
-- Create Table `player`
--

DROP TABLE IF EXISTS `player`;
CREATE TABLE `player` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `national_id` int(11) NOT NULL,
  `image` varchar(1000) DEFAULT NULL,
  `status` tinyint(4) NOT NULL,
  `date_of_birth` varchar(15) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_player_national` (`national_id`)
) ENGINE=MyISAM AUTO_INCREMENT=69 DEFAULT CHARSET=latin1;

--
-- Data for Table `player`
--

/*!40000 ALTER TABLE `player` DISABLE KEYS */;
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('1','Ronnie O\'Sullivan','1','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('2','Ding Junhui','2','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('3','Mark Selby','1','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('4','Neil Robertson','8','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('5','Stuart Bingham','1','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('6','Marco Fu','10','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('7','Ricky Walden','1','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('8','Xiao Guodong','2','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('9','Adam Duffy','1','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('10','Jack Lisowski','1','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('11','Mike Dunn','1','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('12','Jamie Burnett','3','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('13','Fergal O\'Brien','9','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('14','Zhang Anda','2','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('15','Michael Holt','1','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('16','Scott Donaldson','1','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('17','Jimmy Robertson','1','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('18','Ian Glover','1','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('19','Ryan Day','6','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('20','Luca Brecel','11','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('23','Shaun Murphy','1','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('24','Judd Trump','1','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('25','Barry Hawkins','1','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('26','Joe Perry','1','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('27','Mark Allen','4','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('28','John Higgins','3','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('29','Mark Williams','6','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('30','Stephen Maguire','3','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('31','Robert Milkins','1','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('32','Michael White','6','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('33','Graeme Dott','3','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('34','Mark Davis','1','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('35','Liang Wenbo','2','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('36','Alan McManus','3','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('37','Anthony McGill','3','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('38','Martin Gould','1','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('39','Matthew Stevens','6','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('40','Allister Carter','1','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('41','Matthew Selt','1','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('42','Peter Ebdon','1','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('43','Ben Woollaston','1','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('44','Dominic Dale','6','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('45','Gary Wilson','1','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('46','David Gilbert','1','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('47','Mark King','1','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('48','Kurt Maflin','14','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('49','Jamie Jones','6','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('50','Rod Lawler','1','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('51','Gerard Greene','4','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('52','Dechawat Poomjaeng','7','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('53','Ken Doherty','9','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('54','Mark Joyce','1','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('55','Andrew Higginson','1','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('56','Thepchaiya Un-nooh','7','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('57','Robbie Williams','1','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('58','David Morris','9','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('59','Yu Delu','2','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('60','Aditya Mehta','5','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('61','Li Hang','2','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('62','Kyren Wilson','1','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('63','Peter Lines','1','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('64','Anthony Hamilton','1','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('65','Tom Ford','1','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('66','Cao Yupeng','2','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('67','Robin Hull','12','','1','1');
INSERT INTO `player` (`id`,`name`,`national_id`,`image`,`status`,`date_of_birth`) VALUES ('68','Rory McLeod','1','','1','1');
/*!40000 ALTER TABLE `player` ENABLE KEYS */;


--
-- Create Table `position`
--

DROP TABLE IF EXISTS `position`;
CREATE TABLE `position` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Data for Table `position`
--

/*!40000 ALTER TABLE `position` DISABLE KEYS */;
INSERT INTO `position` (`id`,`name`) VALUES ('1','Champion');
INSERT INTO `position` (`id`,`name`) VALUES ('2','Runner-up');
INSERT INTO `position` (`id`,`name`) VALUES ('3','Go to Semi-finals');
INSERT INTO `position` (`id`,`name`) VALUES ('4','Go to Quarter-finals');
INSERT INTO `position` (`id`,`name`) VALUES ('5','Go to Last 16');
INSERT INTO `position` (`id`,`name`) VALUES ('6','Go to Last 32');
INSERT INTO `position` (`id`,`name`) VALUES ('7','Go to Last 48');
INSERT INTO `position` (`id`,`name`) VALUES ('8','Go to Last 64');
INSERT INTO `position` (`id`,`name`) VALUES ('9','Go to Last 96');
/*!40000 ALTER TABLE `position` ENABLE KEYS */;


--
-- Create Table `round`
--

DROP TABLE IF EXISTS `round`;
CREATE TABLE `round` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `base_name` varchar(100) NOT NULL,
  `number_player` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Data for Table `round`
--

/*!40000 ALTER TABLE `round` DISABLE KEYS */;
INSERT INTO `round` (`id`,`base_name`,`number_player`) VALUES ('1','Final','2');
INSERT INTO `round` (`id`,`base_name`,`number_player`) VALUES ('2','Semi-finals','4');
INSERT INTO `round` (`id`,`base_name`,`number_player`) VALUES ('3','Quarter-finals','8');
INSERT INTO `round` (`id`,`base_name`,`number_player`) VALUES ('4','Last 16','16');
INSERT INTO `round` (`id`,`base_name`,`number_player`) VALUES ('5','Last 32','32');
INSERT INTO `round` (`id`,`base_name`,`number_player`) VALUES ('6','Last 48','48');
INSERT INTO `round` (`id`,`base_name`,`number_player`) VALUES ('7','Last 64','64');
INSERT INTO `round` (`id`,`base_name`,`number_player`) VALUES ('8','Last 96','96');
/*!40000 ALTER TABLE `round` ENABLE KEYS */;


--
-- Create Table `season`
--

DROP TABLE IF EXISTS `season`;
CREATE TABLE `season` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Data for Table `season`
--

/*!40000 ALTER TABLE `season` DISABLE KEYS */;
INSERT INTO `season` (`id`,`name`,`status`) VALUES ('1','Season 2015/2016','1');
/*!40000 ALTER TABLE `season` ENABLE KEYS */;


--
-- Create Table `season_player`
--

DROP TABLE IF EXISTS `season_player`;
CREATE TABLE `season_player` (
  `season_id` int(11) NOT NULL,
  `player_id` int(11) NOT NULL,
  PRIMARY KEY (`season_id`,`player_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Data for Table `season_player`
--

/*!40000 ALTER TABLE `season_player` DISABLE KEYS */;
INSERT INTO `season_player` (`season_id`,`player_id`) VALUES ('1','1');
/*!40000 ALTER TABLE `season_player` ENABLE KEYS */;


--
-- Create Table `season_tournament`
--

DROP TABLE IF EXISTS `season_tournament`;
CREATE TABLE `season_tournament` (
  `season_id` int(11) NOT NULL,
  `tournament_id` int(11) NOT NULL,
  `tournament_name` varchar(100) DEFAULT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`season_id`,`tournament_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Data for Table `season_tournament`
--

/*!40000 ALTER TABLE `season_tournament` DISABLE KEYS */;
INSERT INTO `season_tournament` (`season_id`,`tournament_id`,`tournament_name`,`status`) VALUES ('1','1','2016 Welsh Open','1');
INSERT INTO `season_tournament` (`season_id`,`tournament_id`,`tournament_name`,`status`) VALUES ('1','3','Australian Goldfields Open 2015','2');
/*!40000 ALTER TABLE `season_tournament` ENABLE KEYS */;


--
-- Create Table `status_frame_detail`
--

DROP TABLE IF EXISTS `status_frame_detail`;
CREATE TABLE `status_frame_detail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Data for Table `status_frame_detail`
--

/*!40000 ALTER TABLE `status_frame_detail` DISABLE KEYS */;
INSERT INTO `status_frame_detail` (`id`,`name`) VALUES ('1','Gain');
INSERT INTO `status_frame_detail` (`id`,`name`) VALUES ('2','Fail');
/*!40000 ALTER TABLE `status_frame_detail` ENABLE KEYS */;


--
-- Create Table `status_match`
--

DROP TABLE IF EXISTS `status_match`;
CREATE TABLE `status_match` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Data for Table `status_match`
--

/*!40000 ALTER TABLE `status_match` DISABLE KEYS */;
INSERT INTO `status_match` (`id`,`name`) VALUES ('1','Not Started');
INSERT INTO `status_match` (`id`,`name`) VALUES ('2','In Progress');
INSERT INTO `status_match` (`id`,`name`) VALUES ('3','Finished');
INSERT INTO `status_match` (`id`,`name`) VALUES ('4','Locked');
/*!40000 ALTER TABLE `status_match` ENABLE KEYS */;


--
-- Create Table `status_national`
--

DROP TABLE IF EXISTS `status_national`;
CREATE TABLE `status_national` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Data for Table `status_national`
--

/*!40000 ALTER TABLE `status_national` DISABLE KEYS */;
/*!40000 ALTER TABLE `status_national` ENABLE KEYS */;


--
-- Create Table `status_player`
--

DROP TABLE IF EXISTS `status_player`;
CREATE TABLE `status_player` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Data for Table `status_player`
--

/*!40000 ALTER TABLE `status_player` DISABLE KEYS */;
INSERT INTO `status_player` (`id`,`name`) VALUES ('1','Active');
/*!40000 ALTER TABLE `status_player` ENABLE KEYS */;


--
-- Create Table `status_season`
--

DROP TABLE IF EXISTS `status_season`;
CREATE TABLE `status_season` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Data for Table `status_season`
--

/*!40000 ALTER TABLE `status_season` DISABLE KEYS */;
INSERT INTO `status_season` (`id`,`name`) VALUES ('1','Active');
/*!40000 ALTER TABLE `status_season` ENABLE KEYS */;


--
-- Create Table `status_season_tournament`
--

DROP TABLE IF EXISTS `status_season_tournament`;
CREATE TABLE `status_season_tournament` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Data for Table `status_season_tournament`
--

/*!40000 ALTER TABLE `status_season_tournament` DISABLE KEYS */;
INSERT INTO `status_season_tournament` (`id`,`name`) VALUES ('1','Not Started');
INSERT INTO `status_season_tournament` (`id`,`name`) VALUES ('2','In Progress');
INSERT INTO `status_season_tournament` (`id`,`name`) VALUES ('3','Finished');
INSERT INTO `status_season_tournament` (`id`,`name`) VALUES ('4','Locked');
/*!40000 ALTER TABLE `status_season_tournament` ENABLE KEYS */;


--
-- Create Table `status_tournament`
--

DROP TABLE IF EXISTS `status_tournament`;
CREATE TABLE `status_tournament` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Data for Table `status_tournament`
--

/*!40000 ALTER TABLE `status_tournament` DISABLE KEYS */;
INSERT INTO `status_tournament` (`id`,`name`) VALUES ('1','Active');
/*!40000 ALTER TABLE `status_tournament` ENABLE KEYS */;


--
-- Create Table `tournament`
--

DROP TABLE IF EXISTS `tournament`;
CREATE TABLE `tournament` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `base_name` varchar(100) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Data for Table `tournament`
--

/*!40000 ALTER TABLE `tournament` DISABLE KEYS */;
INSERT INTO `tournament` (`id`,`base_name`,`status`) VALUES ('1','Welsh Open','1');
INSERT INTO `tournament` (`id`,`base_name`,`status`) VALUES ('2','Shanghai Masters','1');
INSERT INTO `tournament` (`id`,`base_name`,`status`) VALUES ('3','Australian Goldfields Open','1');
INSERT INTO `tournament` (`id`,`base_name`,`status`) VALUES ('4','German Masters','1');
INSERT INTO `tournament` (`id`,`base_name`,`status`) VALUES ('5','UK Championship','1');
/*!40000 ALTER TABLE `tournament` ENABLE KEYS */;


--
-- Create Table `tournament_player`
--

DROP TABLE IF EXISTS `tournament_player`;
CREATE TABLE `tournament_player` (
  `season_id` int(11) NOT NULL,
  `tournament_id` int(11) NOT NULL,
  `player_id` int(11) NOT NULL,
  PRIMARY KEY (`season_id`,`tournament_id`,`player_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Data for Table `tournament_player`
--

/*!40000 ALTER TABLE `tournament_player` DISABLE KEYS */;
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','1','1');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','1','2');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','1','3');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','1','4');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','1','5');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','1','6');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','1','7');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','1','8');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','1','9');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','1','10');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','1','11');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','1','12');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','1','13');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','1','14');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','1','15');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','1','16');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','1','17');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','1','18');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','1','19');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','1','20');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','1','23');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','1','24');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','1','25');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','1','26');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','1','27');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','1','30');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','1','31');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','1','32');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','1','34');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','1','35');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','1','37');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','1','40');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','1','42');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','1','43');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','1','47');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','1','48');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','1','49');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','1','50');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','1','51');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','1','52');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','1','53');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','1','54');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','1','55');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','1','56');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','1','58');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','1','60');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','1','61');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','1','62');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','1','63');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','1','64');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','1','65');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','1','66');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','1','67');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','1','68');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','3','1');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','3','2');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','3','3');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','3','4');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','3','5');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','3','6');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','3','7');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','3','8');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','3','9');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','3','10');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','3','11');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','3','12');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','3','13');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','3','14');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','3','15');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','3','50');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','3','60');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','3','61');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','3','62');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','3','63');
INSERT INTO `tournament_player` (`season_id`,`tournament_id`,`player_id`) VALUES ('1','3','64');
/*!40000 ALTER TABLE `tournament_player` ENABLE KEYS */;


--
-- Create Table `tournament_prize`
--

DROP TABLE IF EXISTS `tournament_prize`;
CREATE TABLE `tournament_prize` (
  `season_id` int(11) NOT NULL,
  `tournament_id` int(11) NOT NULL,
  `position_id` int(11) NOT NULL,
  `prize` int(11) NOT NULL,
  PRIMARY KEY (`season_id`,`tournament_id`,`position_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Data for Table `tournament_prize`
--

/*!40000 ALTER TABLE `tournament_prize` DISABLE KEYS */;
INSERT INTO `tournament_prize` (`season_id`,`tournament_id`,`position_id`,`prize`) VALUES ('1','1','1','150000');
INSERT INTO `tournament_prize` (`season_id`,`tournament_id`,`position_id`,`prize`) VALUES ('1','1','2','75000');
INSERT INTO `tournament_prize` (`season_id`,`tournament_id`,`position_id`,`prize`) VALUES ('1','1','3','40000');
INSERT INTO `tournament_prize` (`season_id`,`tournament_id`,`position_id`,`prize`) VALUES ('1','1','4','15000');
INSERT INTO `tournament_prize` (`season_id`,`tournament_id`,`position_id`,`prize`) VALUES ('1','1','5','7500');
/*!40000 ALTER TABLE `tournament_prize` ENABLE KEYS */;


--
-- Create Table `tournament_round`
--

DROP TABLE IF EXISTS `tournament_round`;
CREATE TABLE `tournament_round` (
  `season_id` int(11) NOT NULL,
  `tournament_id` int(11) NOT NULL,
  `round_id` int(11) NOT NULL,
  `round_name` varchar(100) DEFAULT NULL,
  `race_to` tinyint(4) NOT NULL,
  PRIMARY KEY (`season_id`,`tournament_id`,`round_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Data for Table `tournament_round`
--

/*!40000 ALTER TABLE `tournament_round` DISABLE KEYS */;
INSERT INTO `tournament_round` (`season_id`,`tournament_id`,`round_id`,`round_name`,`race_to`) VALUES ('1','1','1',NULL,'9');
INSERT INTO `tournament_round` (`season_id`,`tournament_id`,`round_id`,`round_name`,`race_to`) VALUES ('1','1','2',NULL,'6');
INSERT INTO `tournament_round` (`season_id`,`tournament_id`,`round_id`,`round_name`,`race_to`) VALUES ('1','1','3',NULL,'5');
INSERT INTO `tournament_round` (`season_id`,`tournament_id`,`round_id`,`round_name`,`race_to`) VALUES ('1','1','4',NULL,'5');
INSERT INTO `tournament_round` (`season_id`,`tournament_id`,`round_id`,`round_name`,`race_to`) VALUES ('1','1','5',NULL,'5');
INSERT INTO `tournament_round` (`season_id`,`tournament_id`,`round_id`,`round_name`,`race_to`) VALUES ('1','1','7',NULL,'4');
INSERT INTO `tournament_round` (`season_id`,`tournament_id`,`round_id`,`round_name`,`race_to`) VALUES ('1','3','7',NULL,'5');
/*!40000 ALTER TABLE `tournament_round` ENABLE KEYS */;


--
-- Create Table `weather_city`
--

DROP TABLE IF EXISTS `weather_city`;
CREATE TABLE `weather_city` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `latitude` double NOT NULL,
  `longtitude` double NOT NULL,
  `country_code` varchar(2) NOT NULL,
  `api_id` varchar(10) NOT NULL,
  `last_updated` varchar(15) NOT NULL DEFAULT '11',
  `weather_now` varchar(5000) NOT NULL DEFAULT '-1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=145 DEFAULT CHARSET=utf8;

--
-- Data for Table `weather_city`
--

/*!40000 ALTER TABLE `weather_city` DISABLE KEYS */;
INSERT INTO `weather_city` (`id`,`name`,`latitude`,`longtitude`,`country_code`,`api_id`,`last_updated`,`weather_now`) VALUES ('100','Songkhla','7.19882','100.5951','TH','1606147','11','-1');
INSERT INTO `weather_city` (`id`,`name`,`latitude`,`longtitude`,`country_code`,`api_id`,`last_updated`,`weather_now`) VALUES ('101','Lampang','18.29232','99.492767','TH','1152473','11','-1');
INSERT INTO `weather_city` (`id`,`name`,`latitude`,`longtitude`,`country_code`,`api_id`,`last_updated`,`weather_now`) VALUES ('102','Trang','7.55633','99.611412','TH','1150007','11','-1');
INSERT INTO `weather_city` (`id`,`name`,`latitude`,`longtitude`,`country_code`,`api_id`,`last_updated`,`weather_now`) VALUES ('103','Krabi','8.07257','98.910522','TH','1152633','11','-1');
INSERT INTO `weather_city` (`id`,`name`,`latitude`,`longtitude`,`country_code`,`api_id`,`last_updated`,`weather_now`) VALUES ('104','Yala','6.53995','101.281281','TH','1604870','11','-1');
INSERT INTO `weather_city` (`id`,`name`,`latitude`,`longtitude`,`country_code`,`api_id`,`last_updated`,`weather_now`) VALUES ('105','Ranong','9.96583','98.634758','TH','1150965','11','-1');
INSERT INTO `weather_city` (`id`,`name`,`latitude`,`longtitude`,`country_code`,`api_id`,`last_updated`,`weather_now`) VALUES ('106','Surin','14.88181','103.493637','TH','1606030','11','-1');
INSERT INTO `weather_city` (`id`,`name`,`latitude`,`longtitude`,`country_code`,`api_id`,`last_updated`,`weather_now`) VALUES ('107','Pak Kret','13.91301','100.498833','TH','1608048','11','-1');
INSERT INTO `weather_city` (`id`,`name`,`latitude`,`longtitude`,`country_code`,`api_id`,`last_updated`,`weather_now`) VALUES ('108','Hat Yai','7.00836','100.476677','TH','1610780','11','-1');
INSERT INTO `weather_city` (`id`,`name`,`latitude`,`longtitude`,`country_code`,`api_id`,`last_updated`,`weather_now`) VALUES ('109','Ubon Ratchathani','15.22483','104.85289','TH','1605245','11','-1');
INSERT INTO `weather_city` (`id`,`name`,`latitude`,`longtitude`,`country_code`,`api_id`,`last_updated`,`weather_now`) VALUES ('110','Yen Vinh','18.66667','105.666672','VN','1560037','11','-1');
INSERT INTO `weather_city` (`id`,`name`,`latitude`,`longtitude`,`country_code`,`api_id`,`last_updated`,`weather_now`) VALUES ('111','Thanh pho Ho Chi Minh','10.75','106.666672','VN','1566083','11','-1');
INSERT INTO `weather_city` (`id`,`name`,`latitude`,`longtitude`,`country_code`,`api_id`,`last_updated`,`weather_now`) VALUES ('112','Hai Duong','20.933331','106.316673','VN','1581326','11','-1');
INSERT INTO `weather_city` (`id`,`name`,`latitude`,`longtitude`,`country_code`,`api_id`,`last_updated`,`weather_now`) VALUES ('113','Turan','16.06778','108.220833','VN','1583992','11','-1');
INSERT INTO `weather_city` (`id`,`name`,`latitude`,`longtitude`,`country_code`,`api_id`,`last_updated`,`weather_now`) VALUES ('114','Bien Hoa','10.95','106.816673','VN','1587923','11','-1');
INSERT INTO `weather_city` (`id`,`name`,`latitude`,`longtitude`,`country_code`,`api_id`,`last_updated`,`weather_now`) VALUES ('115','Can Tho','10.03333','105.783333','VN','1586203','11','-1');
INSERT INTO `weather_city` (`id`,`name`,`latitude`,`longtitude`,`country_code`,`api_id`,`last_updated`,`weather_now`) VALUES ('116','Vung Tau','10.34599','107.084259','VN','1562414','11','-1');
INSERT INTO `weather_city` (`id`,`name`,`latitude`,`longtitude`,`country_code`,`api_id`,`last_updated`,`weather_now`) VALUES ('117','Haiphong','20.85611','106.68222','VN','1581298','11','-1');
INSERT INTO `weather_city` (`id`,`name`,`latitude`,`longtitude`,`country_code`,`api_id`,`last_updated`,`weather_now`) VALUES ('118','Quang Ngai','15.11667','108.800003','VN','1568770','11','-1');
INSERT INTO `weather_city` (`id`,`name`,`latitude`,`longtitude`,`country_code`,`api_id`,`last_updated`,`weather_now`) VALUES ('119','Ninh Binh','20.253889','105.974998','VN','1571968','11','-1');
INSERT INTO `weather_city` (`id`,`name`,`latitude`,`longtitude`,`country_code`,`api_id`,`last_updated`,`weather_now`) VALUES ('120','Buon Ma Thuot','12.66667','108.050003','VN','1586896','11','-1');
INSERT INTO `weather_city` (`id`,`name`,`latitude`,`longtitude`,`country_code`,`api_id`,`last_updated`,`weather_now`) VALUES ('121','Rach Gia','10.01667','105.083328','VN','1568510','11','-1');
INSERT INTO `weather_city` (`id`,`name`,`latitude`,`longtitude`,`country_code`,`api_id`,`last_updated`,`weather_now`) VALUES ('122','Da Lat','11.94646','108.441933','VN','1584071','11','-1');
INSERT INTO `weather_city` (`id`,`name`,`latitude`,`longtitude`,`country_code`,`api_id`,`last_updated`,`weather_now`) VALUES ('123','Quy Nhon','13.76667','109.23333','VN','1568574','11','-1');
INSERT INTO `weather_city` (`id`,`name`,`latitude`,`longtitude`,`country_code`,`api_id`,`last_updated`,`weather_now`) VALUES ('124','Thanh Hoa','19.799999','105.76667','VN','1566166','11','-1');
INSERT INTO `weather_city` (`id`,`name`,`latitude`,`longtitude`,`country_code`,`api_id`,`last_updated`,`weather_now`) VALUES ('125','Hoa Binh','20.81333','105.338333','VN','1580830','11','-1');
INSERT INTO `weather_city` (`id`,`name`,`latitude`,`longtitude`,`country_code`,`api_id`,`last_updated`,`weather_now`) VALUES ('126','Yen Bai','21.700001','104.866669','VN','1560349','11','-1');
INSERT INTO `weather_city` (`id`,`name`,`latitude`,`longtitude`,`country_code`,`api_id`,`last_updated`,`weather_now`) VALUES ('127','My Tho','10.35','106.349998','VN','1574023','11','-1');
INSERT INTO `weather_city` (`id`,`name`,`latitude`,`longtitude`,`country_code`,`api_id`,`last_updated`,`weather_now`) VALUES ('128','Tra Vinh','9.93472','106.345284','VN','1563926','11','-1');
INSERT INTO `weather_city` (`id`,`name`,`latitude`,`longtitude`,`country_code`,`api_id`,`last_updated`,`weather_now`) VALUES ('129','Ca Mau','9.17694','105.150002','VN','1586443','11','-1');
INSERT INTO `weather_city` (`id`,`name`,`latitude`,`longtitude`,`country_code`,`api_id`,`last_updated`,`weather_now`) VALUES ('130','Nam Dinh','20.41667','106.166672','VN','1573517','11','-1');
INSERT INTO `weather_city` (`id`,`name`,`latitude`,`longtitude`,`country_code`,`api_id`,`last_updated`,`weather_now`) VALUES ('131','Ben Tre','10.23333','106.383331','VN','1587976','11','-1');
INSERT INTO `weather_city` (`id`,`name`,`latitude`,`longtitude`,`country_code`,`api_id`,`last_updated`,`weather_now`) VALUES ('132','Lang Son','21.83333','106.73333','VN','1576633','11','-1');
INSERT INTO `weather_city` (`id`,`name`,`latitude`,`longtitude`,`country_code`,`api_id`,`last_updated`,`weather_now`) VALUES ('133','Cao Bang','22.66667','106.25','VN','1586185','11','-1');
INSERT INTO `weather_city` (`id`,`name`,`latitude`,`longtitude`,`country_code`,`api_id`,`last_updated`,`weather_now`) VALUES ('134','Hue','16.466669','107.599998','VN','1580240','11','-1');
INSERT INTO `weather_city` (`id`,`name`,`latitude`,`longtitude`,`country_code`,`api_id`,`last_updated`,`weather_now`) VALUES ('135','Long Xuyen','10.38333','105.416672','VN','1575627','11','-1');
INSERT INTO `weather_city` (`id`,`name`,`latitude`,`longtitude`,`country_code`,`api_id`,`last_updated`,`weather_now`) VALUES ('136','Phan Thiet','10.93333','108.099998','VN','1571058','11','-1');
INSERT INTO `weather_city` (`id`,`name`,`latitude`,`longtitude`,`country_code`,`api_id`,`last_updated`,`weather_now`) VALUES ('137','Kon Tum','14.35','108','VN','1578500','11','-1');
INSERT INTO `weather_city` (`id`,`name`,`latitude`,`longtitude`,`country_code`,`api_id`,`last_updated`,`weather_now`) VALUES ('138','Vinh Yen','21.309999','105.596672','VN','1562548','11','-1');
INSERT INTO `weather_city` (`id`,`name`,`latitude`,`longtitude`,`country_code`,`api_id`,`last_updated`,`weather_now`) VALUES ('139','Ha Tinh','18.33333','105.900002','VN','1581047','11','-1');
INSERT INTO `weather_city` (`id`,`name`,`latitude`,`longtitude`,`country_code`,`api_id`,`last_updated`,`weather_now`) VALUES ('140','Dong Hoi','17.48333','106.599998','VN','1582886','11','-1');
INSERT INTO `weather_city` (`id`,`name`,`latitude`,`longtitude`,`country_code`,`api_id`,`last_updated`,`weather_now`) VALUES ('141','Lyon','45.748459','4.84671','FR','2996944','11','-1');
INSERT INTO `weather_city` (`id`,`name`,`latitude`,`longtitude`,`country_code`,`api_id`,`last_updated`,`weather_now`) VALUES ('142','Montpellier','43.61092','3.87723','FR','2992166','11','-1');
INSERT INTO `weather_city` (`id`,`name`,`latitude`,`longtitude`,`country_code`,`api_id`,`last_updated`,`weather_now`) VALUES ('143','Cestas','44.74345','-0.67905','FR','3027763','11','-1');
INSERT INTO `weather_city` (`id`,`name`,`latitude`,`longtitude`,`country_code`,`api_id`,`last_updated`,`weather_now`) VALUES ('144','Toulouse','43.604259','1.44367','FR','2972315','11','-1');
/*!40000 ALTER TABLE `weather_city` ENABLE KEYS */;

SET FOREIGN_KEY_CHECKS=1;
-- EOB

